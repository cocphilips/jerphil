Our shape predictor for dlib was sourced from the following Hugging Face repository:

https://huggingface.co/spaces/liangtian/birthdayCrown/blob/e96083d163606933a2cc74be372895f3cc5d1b96/shape_predictor_81_face_landmarks.dat